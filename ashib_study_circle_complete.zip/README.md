# Ashib Study Circle Website
Ready to deploy on Netlify!

### Included Files:
1. `index.html` - Homepage with subjects, navigation, and notes preview.
2. `notes.html` - Dedicated study notes repository page.
3. `style.css` - Professional styling for the entire website.
4. `netlify.toml` - Netlify deployment configuration.
